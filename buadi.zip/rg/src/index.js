import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import './index.css';
import App from './App';
import Login from './login'; // Import the default export
import Instructors from './instructorContact';
import Grade from './gradeReport';
import MissingGrades from './missingGradeForm';
import Dashboard from './Dashboard';
import reportWebVitals from './reportWebVitals';
import HelpAndSupport from './HelpAndSupport';
import LandingPage from './LandingPage';

function MyRouter() {
  return (
    <React.StrictMode>
      <BrowserRouter>
        <Routes>
          <Route path='/' element={<App />} />
          <Route path='/login' element={<Login />} />
          <Route path='/instructors' element={<Instructors />} />
          <Route path='/faq' element={<HelpAndSupport />} />
          <Route path='/grades' element={<Grade />} />
          <Route path='/missing-grades' element={<MissingGrades />} />
          <Route path='/dashboard' element={<Dashboard />} />
          <Route path='/landingpage' element={<LandingPage />} />
        </Routes>
      </BrowserRouter>
    </React.StrictMode>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<MyRouter />);

reportWebVitals();
