// src/components/InstructorContactPage.jsx
import React, { useState } from 'react';
import './InstructorContactPage.css';  // Import a CSS file for styling

const InstructorContactPage = () => {
  const [instructors, setInstructors] = useState([
    { name: 'John Doe', email: 'john.doe@example.com' },
    { name: 'Jane Smith', email: 'jane.smith@example.com' },
    { name: 'Bob Johnson', email: 'bob.johnson@example.com' },
    // ... add more instructors as needed
  ]);

  const [selectedInstructor, setSelectedInstructor] = useState(null);
  const [emailSubject, setEmailSubject] = useState('');
  const [emailBody, setEmailBody] = useState('');

  const handleSendEmail = () => {
    // Implement email sending logic here
    console.log(`Email sent to ${selectedInstructor.name}:`, { emailSubject, emailBody });
    // Placeholder logic, replace with actual email sending logic
  };

  return (
    <div className="instructor-contact-container">
      <h2>Instructor Contact</h2>
      <div className="instructors-list">
        <ul>
          {instructors.map((instructor, index) => (
            <li key={index} onClick={() => setSelectedInstructor(instructor)}>
              {instructor.name}
            </li>
          ))}
        </ul>
      </div>
      {selectedInstructor && (
        <div className="email-form">
          <h3>Contact {selectedInstructor.name}</h3>
          <form>
            <div className="form-group">
              <label htmlFor="emailSubject">Subject:</label>
              <input
                type="text"
                id="emailSubject"
                value={emailSubject}
                onChange={(e) => setEmailSubject(e.target.value)}
                required
              />
            </div>
            <div className="form-group">
              <label htmlFor="emailBody">Email Body:</label>
              <textarea
                id="emailBody"
                value={emailBody}
                onChange={(e) => setEmailBody(e.target.value)}
                required
              ></textarea>
            </div>
            <button type="button" onClick={handleSendEmail}>
              Send Email
            </button>
          </form>
        </div>
      )}
    </div>
  );
};

export default InstructorContactPage;
