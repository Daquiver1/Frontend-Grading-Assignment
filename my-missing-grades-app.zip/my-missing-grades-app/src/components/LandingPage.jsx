// src/components/LandingPage.jsx
import React from 'react';
import { Link } from 'react-router-dom';
import './LandingPage.css';  // Import a CSS file for styling

const LandingPage = () => {
  return (
    <div className="landing-page">
      <header>
        <h1>Welcome to the Missing Grade Reporting System</h1>
        <p>Track and report grades not recorded in your academic profiles.</p>
      </header>
      <section className="features">
        <div>
          <h2>Features</h2>
          <ul>
            <li>View your current grades on the Dashboard</li>
            <li>Report missing grades using the Grade Report form</li>
            <li>Contact instructors on the Instructor Contact page</li>
          </ul>
        </div>
      </section>
      <section className="get-started">
        <h2>Get Started</h2>
        <p>
          To get started, please <Link to="/login">login</Link> to your account.
          If you don't have an account, you can <Link to="/signup">sign up</Link> now.
        </p>
      </section>
      <nav>
        <ul>
          <li>
            <Link to="/login">Login</Link>
          </li>
          <li>
            <Link to="/dashboard">Dashboard</Link>
          </li>
          <li>
            <Link to="/grade-report">Grade Report</Link>
          </li>
          <li>
            <Link to="/instructor-contact">Instructor Contact</Link>
          </li>
          {/* Add links for other pages */}
        </ul>
      </nav>
    </div>
  );
};

export default LandingPage;
