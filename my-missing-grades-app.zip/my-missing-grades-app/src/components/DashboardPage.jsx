// src/components/DashboardPage.jsx
import React, { useState, useEffect } from 'react';
import './DashboardPage.css';

const DashboardPage = () => {
  const [grades, setGrades] = useState([]);

  useEffect(() => {
    // Fetch grades data from your API or mock data
    // For now, using a placeholder array
    const mockGrades = [
      { course: 'Math', grade: 'A' },
      { course: 'English', grade: 'B' },
      { course: 'History', grade: 'C' },
      // ... add more courses as needed
    ];
    setGrades(mockGrades);
  }, []);

  return (
    <div className="dashboard-container">
      <h2>Dashboard</h2>
      <div className="grades-container">
        {grades.length === 0 ? (
          <p>No grades available</p>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Course</th>
                <th>Grade</th>
              </tr>
            </thead>
            <tbody>
              {grades.map((grade, index) => (
                <tr key={index}>
                  <td>{grade.course}</td>
                  <td>{grade.grade}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};

export default DashboardPage;
