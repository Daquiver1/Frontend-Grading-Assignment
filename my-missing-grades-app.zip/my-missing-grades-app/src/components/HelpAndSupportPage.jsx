// src/components/HelpAndSupportPage.jsx
import React, { useState } from 'react';
import './HelpAndSupportPage.css';  // Import a CSS file for styling

const HelpAndSupportPage = () => {
  const [contactForm, setContactForm] = useState({
    name: '',
    email: '',
    message: '',
  });

  const handleContactFormChange = (e) => {
    setContactForm({
      ...contactForm,
      [e.target.name]: e.target.value,
    });
  };

  const handleContactFormSubmit = () => {
    // Implement form submission logic here
    console.log('Contact form submitted:', contactForm);
    // Placeholder logic, replace with actual form submission logic
  };

  return (
    <div className="help-and-support-container">
      <h2>Help and Support</h2>
      <div className="faq-section">
        <h3>Frequently Asked Questions</h3>
        <ul>
          <li>Q: How do I report a missing grade?</li>
          <li>A: Navigate to the "Missing Grade Form" page and fill out the form.</li>
          {/* Add more FAQ items as needed */}
        </ul>
      </div>
      <div className="contact-form">
        <h3>Contact Technical Support</h3>
        <form onSubmit={handleContactFormSubmit}>
          <div className="form-group">
            <label htmlFor="name">Your Name:</label>
            <input
              type="text"
              id="name"
              name="name"
              value={contactForm.name}
              onChange={handleContactFormChange}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="email">Your Email:</label>
            <input
              type="email"
              id="email"
              name="email"
              value={contactForm.email}
              onChange={handleContactFormChange}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="message">Your Message:</label>
            <textarea
              id="message"
              name="message"
              value={contactForm.message}
              onChange={handleContactFormChange}
              required
            ></textarea>
          </div>
          <button type="submit">Submit</button>
        </form>
      </div>
    </div>
  );
};

export default HelpAndSupportPage;
