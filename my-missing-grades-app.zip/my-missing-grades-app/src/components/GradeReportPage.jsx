// src/components/GradeReportPage.jsx
import React, { useState, useEffect } from 'react';
import './GradeReportPage.css';  // Import a CSS file for styling

const GradeReportPage = () => {
  const [grades, setGrades] = useState([]);  // Placeholder for student grades

  useEffect(() => {
    // Fetch grades data from your API or mock data
    // For now, using a placeholder array
    const mockGrades = [
      { course: 'Math', grade: 'A', semester: 'Fall 2022' },
      { course: 'English', grade: 'B', semester: 'Fall 2022' },
      { course: 'History', grade: 'C', semester: 'Spring 2023' },
      // ... add more courses as needed
    ];
    setGrades(mockGrades);
  }, []);

  // Placeholder for filter options
  const filterOptions = ['All', 'Fall 2022', 'Spring 2023', 'Summer 2023'];

  const [selectedFilter, setSelectedFilter] = useState('All');

  const filteredGrades = selectedFilter === 'All'
    ? grades
    : grades.filter(grade => grade.semester === selectedFilter);

  return (
    <div className="grade-report-container">
      <h2>Grade Report</h2>
      <div className="filter-container">
        <label htmlFor="semesterFilter">Filter by Semester:</label>
        <select
          id="semesterFilter"
          onChange={(e) => setSelectedFilter(e.target.value)}
          value={selectedFilter}
        >
          {filterOptions.map((option, index) => (
            <option key={index} value={option}>{option}</option>
          ))}
        </select>
      </div>
      <div className="grades-container">
        {filteredGrades.length === 0 ? (
          <p>No grades available</p>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Course</th>
                <th>Grade</th>
                <th>Semester</th>
              </tr>
            </thead>
            <tbody>
              {filteredGrades.map((grade, index) => (
                <tr key={index}>
                  <td>{grade.course}</td>
                  <td>{grade.grade}</td>
                  <td>{grade.semester}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};

export default GradeReportPage;
