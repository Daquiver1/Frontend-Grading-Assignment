// src/data/mockData.js

export const students = [
    {
      id: 1,
      name: 'John Doe',
      // other student properties
    },
    {
      id: 2,
      name: 'Jane Doe',
      // other student properties
    },
    // ... add more student objects
  ];
  
  export const grades = [
    {
      courseId: 1,
      studentId: 1,
      grade: 'A',
      // other grade properties
    },
    {
      courseId: 2,
      studentId: 1,
      grade: 'B',
      // other grade properties
    },
    // ... add more grade objects
  ];
  
  export const instructors = [
    {
      id: 1,
      name: 'Professor Smith',
      // other instructor properties
    },
    {
      id: 2,
      name: 'Professor Johnson',
      // other instructor properties
    },
    // ... add more instructor objects
  ];
  